public enum SalaryRange {
		less25, from25to40, from40to70, more70;
	}