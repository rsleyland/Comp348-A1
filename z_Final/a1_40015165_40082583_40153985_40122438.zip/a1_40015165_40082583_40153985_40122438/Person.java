
public interface Person {
	String getId();
	String getName();
}
